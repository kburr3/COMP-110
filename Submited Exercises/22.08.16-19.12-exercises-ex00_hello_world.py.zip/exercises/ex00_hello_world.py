"""My first program for COMP110"""

__author__="730470131"

print("Hello, world.")